﻿using Microsoft.EntityFrameworkCore;
using Phonebook.Api.Entities;

namespace Phonebook.Api.Infrastructure;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options)
    {
    }

    public DbSet<PhonebookEntry> PhonebookEntries => Set<PhonebookEntry>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<PhonebookEntry>(b =>
        {
            b.ToTable("phonebook_entries");
            b.HasKey(x => x.Id);

            b.HasIndex(x => x.Phone).IsUnique();

            // Soft delete: default filter
            b.HasQueryFilter(x => x.IsActive);

            b.Property(x => x.Name).IsRequired().HasMaxLength(100);
            b.Property(x => x.Surname).IsRequired().HasMaxLength(100);
            b.Property(x => x.Phone).IsRequired().HasMaxLength(30);
            b.Property(x => x.Email).HasMaxLength(200);
        });
    }
}