﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Phonebook.Api.Entities;
using Phonebook.Api.Infrastructure;
using Phonebook.Api.Models;

namespace Phonebook.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PersonsController : ControllerBase
{
    private readonly AppDbContext _db;

    public PersonsController(AppDbContext db)
    {
        _db = db;
    }

    // GET /api/persons?query=ali
    [HttpGet]
    public async Task<ActionResult<List<PersonResponse>>> GetAll([FromQuery] string? query, CancellationToken ct)
    {
        IQueryable<Person> q = _db.Persons.AsNoTracking();

        if (!string.IsNullOrWhiteSpace(query))
        {
            var term = query.Trim().ToLower();

            q = q.Where(x =>
                x.Name.ToLower().Contains(term) ||
                x.Surname.ToLower().Contains(term) ||
                (x.Email != null && x.Email.ToLower().Contains(term)) ||
                x.PhoneNumber.ToLower().Contains(term));
        }

        var list = await q
            .OrderBy(x => x.Name).ThenBy(x => x.Surname)
            .Select(x => new PersonResponse
            {
                Id = x.Id,
                Name = x.Name,
                Surname = x.Surname,
                Age = x.Age,
                Email = x.Email,
                PhoneNumber = x.PhoneNumber,
                CreatedAtUtc = x.CreatedAtUtc,
                UpdatedAtUtc = x.UpdatedAtUtc
            })
            .ToListAsync(ct);

        return Ok(list);
    }

    // GET /api/persons/5
    [HttpGet("{id:long}")]
    public async Task<ActionResult<PersonResponse>> GetById(long id, CancellationToken ct)
    {
        var p = await _db.Persons.AsNoTracking()
            .Where(x => x.Id == id)
            .Select(x => new PersonResponse
            {
                Id = x.Id,
                Name = x.Name,
                Surname = x.Surname,
                Age = x.Age,
                Email = x.Email,
                PhoneNumber = x.PhoneNumber,
                CreatedAtUtc = x.CreatedAtUtc,
                UpdatedAtUtc = x.UpdatedAtUtc
            })
            .SingleOrDefaultAsync(ct);

        if (p == null) return NotFound();
        return Ok(p);
    }

    // POST /api/persons
    [HttpPost]
    public async Task<ActionResult<PersonResponse>> Create(PersonCreateRequest req, CancellationToken ct)
    {
        // Unique phone check (DB unique index var ama önce düzgün mesaj verelim)
        var exists = await _db.Persons.AnyAsync(x => x.PhoneNumber == req.PhoneNumber, ct);
        if (exists) return Conflict(new { message = "PhoneNumber already exists." });

        var entity = new Person
        {
            Name = req.Name.Trim(),
            Surname = req.Surname.Trim(),
            Age = req.Age,
            Email = string.IsNullOrWhiteSpace(req.Email) ? null : req.Email.Trim(),
            PhoneNumber = req.PhoneNumber.Trim(),
            IsActive = true,
            CreatedAtUtc = DateTime.UtcNow,
            UpdatedAtUtc = null
        };

        _db.Persons.Add(entity);
        await _db.SaveChangesAsync(ct);

        var res = new PersonResponse
        {
            Id = entity.Id,
            Name = entity.Name,
            Surname = entity.Surname,
            Age = entity.Age,
            Email = entity.Email,
            PhoneNumber = entity.PhoneNumber,
            CreatedAtUtc = entity.CreatedAtUtc,
            UpdatedAtUtc = entity.UpdatedAtUtc
        };

        return CreatedAtAction(nameof(GetById), new { id = entity.Id }, res);
    }

    // PUT /api/persons/5
    [HttpPut("{id:long}")]
    public async Task<IActionResult> Update(long id, PersonUpdateRequest req, CancellationToken ct)
    {
        var entity = await _db.Persons.SingleOrDefaultAsync(x => x.Id == id, ct);
        if (entity == null) return NotFound();

        var phoneExists = await _db.Persons.AnyAsync(x => x.PhoneNumber == req.PhoneNumber && x.Id != id, ct);
        if (phoneExists) return Conflict(new { message = "PhoneNumber already exists." });

        entity.Name = req.Name.Trim();
        entity.Surname = req.Surname.Trim();
        entity.Age = req.Age;
        entity.Email = string.IsNullOrWhiteSpace(req.Email) ? null : req.Email.Trim();
        entity.PhoneNumber = req.PhoneNumber.Trim();
        entity.UpdatedAtUtc = DateTime.UtcNow;

        await _db.SaveChangesAsync(ct);
        return NoContent();
    }

    // DELETE /api/persons/5  (soft delete)
    [HttpDelete("{id:long}")]
    public async Task<IActionResult> Delete(long id, CancellationToken ct)
    {
        var entity = await _db.Persons.SingleOrDefaultAsync(x => x.Id == id, ct);
        if (entity == null) return NotFound();

        entity.IsActive = false;
        entity.UpdatedAtUtc = DateTime.UtcNow;

        await _db.SaveChangesAsync(ct);
        return NoContent();
    }
}
