﻿namespace Phonebook.Api.Entities
{
    public class Class1
    {
    }
}
